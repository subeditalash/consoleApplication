﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace applicationDevelopmentCW1
{
    class RateList
    {
        public string TicketRate { get; set; }
        public string Child { get; set; }
        public string Adult { get; set; }

        public string GroupOfFive { get; set; }
        public string GroupOfTen { get; set; }
    }
}
