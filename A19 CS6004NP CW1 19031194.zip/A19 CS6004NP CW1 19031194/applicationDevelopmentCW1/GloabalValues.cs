﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace applicationDevelopmentCW1
{
    class GloabalValues
    {
        
        public static List<RateList> RateList = new List<RateList>();
    }

}
